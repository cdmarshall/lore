# THREE brand pack: where it came from

Built 2026-10-14. Refresh by saying "refresh my brand" (workflows/brand.md).

- **Brand guidelines:** THREE Brand Guidelines, August 2026 (51 pages), attached in Notion → THREE wiki → Go-to-Market (GTM) Hub → Brand & messaging. Not stored here (60 MB, internal). Pages used: 10 to 19 (logo, symbol, clear space, don'ts), 21 to 22 (type and hierarchy), 24 to 26 (color), 40 to 42 (icons, infographics).
- **Website:** threeinsurance.com computed styles and CSS custom properties (`--color-orange #c15109`, `--color-three-orange #bb4f09`, `--color-gunmetal #2b2b2a`, `--color-off-white #f7f6f6`, `--color-grey #6b6d70`, `--color-blue-steel #324970`, `--color-gold #ab7e55`, `--color-dark-orange #913b04`, `--color-cream #cbc4c1`, green `#00752c`, red `#d82313`); buttons 2px radius, uppercase Nexa.
- **Logo:** the full-color primary logo SVG from the site header (`logo.svg`); `symbol.svg` is the mark alone.

## Decisions

- **Type.** Guidelines: Nexa (headlines, eyebrows, CTAs; Adobe Fonts) and Hanken Grotesk (body, metadata; Google Fonts). Hanken Grotesk is embedded (OFL). Nexa is licensed through Adobe Fonts, so it is only referenced with `local()`; Outfit (OFL) is the embedded look-alike. If marketing can share a Nexa web license, drop the woff2 files in `fonts/` and point the `THREE Display` faces at them.
- **Lore's accent.** Lore reserves one accent color for its own moments (Lore chips, the triage pile). Here that is Magenta Steel `#9b3b6f`, which the guidelines mark for internal use only. Lore's artifacts are internal, so it fits; don't carry it into anything customer-facing.
- **Hierarchy.** Headline 2 (Nexa Light, sentence case) for mastheads; eyebrow labels in Nexa caps; body in Hanken Grotesk Light.
- **Logo use.** The logo sits alone in the top-right of mastheads, never locked up with a product name (guidelines p17: no product lockups). Lore's titles ("Action items", "Daily brief") stay separate text, credited "by Lore".
- **Charts.** Solid fills, soft line curves, Copper first then Blue Steel, Gold, Bright Copper, Cream (guidelines p42).
